import { expect, test, type Page } from '@playwright/test';
import fs from 'node:fs';
import { e2eMailboxPath } from '../e2ePaths.js';

const employeeEmail = 'employe@atlas-industrial.ma';
const recoveryPassword = 'E2e#Recovery2026!';

async function login(page: Page, identifier: string, password: string, expectedRole?: string) {
  await page.goto('/');
  await page.locator('#login-identifier').fill(identifier);
  await page.locator('#login-password').fill(password);
  const loginResponse = page.waitForResponse((response) =>
    response.url().endsWith('/api/auth/login') && response.request().method() === 'POST'
  );
  await page.getByRole('button', { name: 'Se connecter', exact: true }).click();
  const response = await loginResponse;
  expect(response.status()).toBe(200);
  const data = await response.json() as { user: { role_code: string } };
  if (expectedRole) expect(data.user.role_code).toBe(expectedRole);
  await expect(page).toHaveURL(/\/$/);
}

async function logout(page: Page) {
  await page.locator('header button').last().click();
  await page.getByRole('button', { name: 'Déconnexion', exact: true }).click();
  await expect(page.locator('#login-identifier')).toBeVisible();
}

test('OTP recovery uses mocked email and resets the isolated fixture account', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('button', { name: 'Mot de passe oublié ?' }).click();
  const dialog = page.getByRole('dialog');
  await expect(dialog).toBeVisible();
  await page.locator('#otp-recovery-email').fill(employeeEmail);
  await dialog.getByRole('button', { name: 'Envoyer le code' }).click();
  await expect(dialog.getByText(/recevrez un code de réinitialisation/)).toBeVisible();

  await expect.poll(() => fs.existsSync(e2eMailboxPath)).toBe(true);
  const code = fs.readFileSync(e2eMailboxPath, 'utf8');
  await page.locator('#otp-recovery-code').fill(code);
  await dialog.getByRole('button', { name: 'Vérifier le code' }).click();
  await expect(dialog.getByText(/Code vérifié/)).toBeVisible();
  await dialog.getByLabel('Nouveau mot de passe').fill(recoveryPassword);
  await dialog.getByLabel('Confirmer le mot de passe').fill(recoveryPassword);
  await dialog.getByRole('button', { name: 'Réinitialiser le mot de passe' }).click();
  await expect(dialog).toBeHidden();

  await login(page, 'ATL-010', recoveryPassword, 'EMPLOYEE');
  await expect(page.getByText('Tableau de bord').first()).toBeVisible();
});

test('all five roles sign in, retain protected-route boundaries, and sign out', async ({ page }) => {
  const roles = [
    { role: 'SUPER_ADMIN', identifier: 'SA-001', password: 'PlusHR#Super2026!', allowed: '/companies' },
    { role: 'COMPANY_ADMIN', identifier: 'admin@atlas-industrial.ma', password: 'Atlas#Admin2026!', allowed: '/employees' },
    { role: 'HR_MANAGER', identifier: 'ATL-002', password: 'Atlas#HR2026!', allowed: '/payroll' },
    { role: 'MANAGER', identifier: 'ATL-003', password: 'Atlas#Mgr2026!', allowed: '/tasks' },
    { role: 'EMPLOYEE', identifier: 'ATL-010', password: recoveryPassword, allowed: '/tasks' },
  ];

  for (const fixture of roles) {
    await login(page, fixture.identifier, fixture.password, fixture.role);
    await page.goto(fixture.allowed);
    await expect(page.getByText('Accès non autorisé')).toHaveCount(0);

    if (fixture.role === 'EMPLOYEE') {
      await page.goto('/companies');
      await expect(page.getByText('Accès non autorisé')).toBeVisible();
    }

    if (fixture.role === 'COMPANY_ADMIN') {
      const employeesResponse = page.waitForResponse((response) =>
        response.url().endsWith('/api/employees') && response.request().method() === 'GET'
      );
      await page.goto('/employees');
      const response = await employeesResponse;
      expect(response.status()).toBe(200);
      const data = await response.json() as { employees: Array<{ company_id: string }> };
      expect(data.employees.every((employee) => employee.company_id === 'comp-atlas')).toBe(true);
    }

    await logout(page);
  }
});

test('landing page has no horizontal overflow at mobile width', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto('/');
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(390);
  await expect(page.locator('#login-identifier')).toBeVisible();
});
